package com.example.fragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button add, remove;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Fragment1 f1 = new Fragment1();
        add = findViewById(R.id.add);
        remove = findViewById(R.id.remove);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                frag(f1);
            }
        });
        remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rfrag(f1);
            }
        });
    }

    public void frag(Fragment fr) {
        getSupportFragmentManager().beginTransaction().add(R.id.frame1, fr).commit();
    }

    public void rfrag(Fragment fr) {
        getSupportFragmentManager().beginTransaction().remove(fr).commit();
    }
}